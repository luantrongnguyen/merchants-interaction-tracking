export declare const appConfig: {
    spreadsheetId: string;
    googleCredentialsPath: string;
    port: number;
};
