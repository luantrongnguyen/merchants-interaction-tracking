"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appConfig = void 0;
exports.appConfig = {
    spreadsheetId: '1UhHDxAi74gnflgxQhlnF8ZniWRQIC0cVNJkzP4NnA5E',
    googleCredentialsPath: './google-credentials.json',
    port: 3001,
};
//# sourceMappingURL=app.config.js.map