import { CreateMerchantDto } from './create-merchant.dto';
declare const UpdateMerchantDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateMerchantDto>>;
export declare class UpdateMerchantDto extends UpdateMerchantDto_base {
}
export {};
