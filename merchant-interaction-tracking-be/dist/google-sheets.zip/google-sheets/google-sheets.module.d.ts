export declare class GoogleSheetsModule {
}
